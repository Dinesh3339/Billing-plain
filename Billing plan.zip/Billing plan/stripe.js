// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Navbar scroll effect with transparency
const navbar = document.querySelector('.navbar');
let lastScroll = 0;

window.addEventListener('scroll', () => {
    const currentScroll = window.pageYOffset;
    
    // Add transparency based on scroll position
    const transparency = Math.min(currentScroll / 500, 0.9);
    navbar.style.backgroundColor = `rgba(255, 255, 255, ${0.9 - transparency})`;
    
    // Hide/show navbar based on scroll direction
    if (currentScroll > lastScroll && currentScroll > 100) {
        navbar.style.transform = 'translateY(-100%)';
    } else {
        navbar.style.transform = 'translateY(0)';
    }
    
    lastScroll = currentScroll;
});

// Testimonial slider
const testimonialSlider = document.querySelector('.testimonial-slider');
let isDown = false;
let startX;
let scrollLeft;

testimonialSlider.addEventListener('mousedown', (e) => {
    isDown = true;
    testimonialSlider.classList.add('active');
    startX = e.pageX - testimonialSlider.offsetLeft;
    scrollLeft = testimonialSlider.scrollLeft;
});

testimonialSlider.addEventListener('mouseleave', () => {
    isDown = false;
    testimonialSlider.classList.remove('active');
});

testimonialSlider.addEventListener('mouseup', () => {
    isDown = false;
    testimonialSlider.classList.remove('active');
});

testimonialSlider.addEventListener('mousemove', (e) => {
    if (!isDown) return;
    e.preventDefault();
    const x = e.pageX - testimonialSlider.offsetLeft;
    const walk = (x - startX) * 2;
    testimonialSlider.scrollLeft = scrollLeft - walk;
});

// Testimonial slider functionality
const testimonialCards = document.querySelectorAll('.testimonial-card');
const prevBtn = document.querySelector('.prev-btn');
const nextBtn = document.querySelector('.next-btn');
const dotsContainer = document.querySelector('.testimonial-dots');

// Create dots
testimonialCards.forEach((_, index) => {
    const dot = document.createElement('div');
    dot.classList.add('dot');
    if (index === 0) dot.classList.add('active');
    dot.addEventListener('click', () => scrollToCard(index));
    dotsContainer.appendChild(dot);
});

const dots = document.querySelectorAll('.dot');

// Scroll to specific card
function scrollToCard(index) {
    const card = testimonialCards[index];
    testimonialSlider.scrollTo({
        left: card.offsetLeft - testimonialSlider.offsetLeft,
        behavior: 'smooth'
    });
    updateDots(index);
}

// Update active dot
function updateDots(activeIndex) {
    dots.forEach((dot, index) => {
        dot.classList.toggle('active', index === activeIndex);
    });
}

// Previous button click
prevBtn.addEventListener('click', () => {
    const currentScroll = testimonialSlider.scrollLeft;
    const cardWidth = testimonialCards[0].offsetWidth + 32; // Including gap
    const previousScroll = currentScroll - cardWidth;
    
    testimonialSlider.scrollTo({
        left: previousScroll,
        behavior: 'smooth'
    });
});

// Next button click
nextBtn.addEventListener('click', () => {
    const currentScroll = testimonialSlider.scrollLeft;
    const cardWidth = testimonialCards[0].offsetWidth + 32; // Including gap
    const nextScroll = currentScroll + cardWidth;
    
    testimonialSlider.scrollTo({
        left: nextScroll,
        behavior: 'smooth'
    });
});

// Update dots on scroll
testimonialSlider.addEventListener('scroll', () => {
    const cardWidth = testimonialCards[0].offsetWidth + 32;
    const currentIndex = Math.round(testimonialSlider.scrollLeft / cardWidth);
    updateDots(currentIndex);
});

// Auto scroll testimonials
let autoScrollInterval;

function startAutoScroll() {
    autoScrollInterval = setInterval(() => {
        const currentScroll = testimonialSlider.scrollLeft;
        const maxScroll = testimonialSlider.scrollWidth - testimonialSlider.clientWidth;
        
        if (currentScroll >= maxScroll) {
            testimonialSlider.scrollTo({
                left: 0,
                behavior: 'smooth'
            });
        } else {
            const cardWidth = testimonialCards[0].offsetWidth + 32;
            testimonialSlider.scrollTo({
                left: currentScroll + cardWidth,
                behavior: 'smooth'
            });
        }
    }, 5000);
}

function stopAutoScroll() {
    clearInterval(autoScrollInterval);
}

// Start auto scroll
startAutoScroll();

// Pause auto scroll on hover or touch
testimonialSlider.addEventListener('mouseenter', stopAutoScroll);
testimonialSlider.addEventListener('touchstart', stopAutoScroll);

// Resume auto scroll when mouse leaves
testimonialSlider.addEventListener('mouseleave', startAutoScroll);
testimonialSlider.addEventListener('touchend', startAutoScroll);

// Intersection Observer for animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.classList.add('fade-in');
            if (entry.target.classList.contains('stat-bubble')) {
                animateCounter(entry.target.querySelector('.counter'));
            }
            observer.unobserve(entry.target);
        }
    });
}, observerOptions);

// Observe elements for animation
document.querySelectorAll('.benefit-card, .feature-item, .testimonial-card, .stat-bubble, .pricing-card').forEach(el => {
    observer.observe(el);
});

// Counter animation
function animateCounter(element) {
    const target = parseInt(element.textContent);
    let current = 0;
    const increment = target / 50; // Adjust speed here
    const timer = setInterval(() => {
        current += increment;
        if (current >= target) {
            element.textContent = target + '+';
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(current) + '+';
        }
    }, 20);
}

// Join button click handler with loading animation
document.querySelectorAll('.join-btn, .cta-btn').forEach(button => {
    button.addEventListener('click', async () => {
        button.classList.add('loading');
        button.disabled = true;
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1500));
        
        // Show success message
        const originalText = button.textContent;
        button.textContent = 'Welcome! 🎉';
        button.classList.remove('loading');
        
        setTimeout(() => {
            button.textContent = originalText;
            button.disabled = false;
        }, 2000);
    });
});

// Payment Modal Functionality
const modal = document.getElementById('payment-modal');
const joinButtons = document.querySelectorAll('.join-btn, .cta-btn, .get-started-btn');
const closeBtn = document.querySelector('.close');

joinButtons.forEach(button => {
    button.addEventListener('click', () => {
        modal.style.display = 'block';
    });
});

closeBtn.addEventListener('click', () => {
    modal.style.display = 'none';
});

window.addEventListener('click', (event) => {
    if (event.target === modal) {
        modal.style.display = 'none';
    }
});

// Parallax effect for hero section
window.addEventListener('scroll', () => {
    const hero = document.querySelector('.hero');
    const scrolled = window.pageYOffset;
    hero.style.backgroundPositionY = scrolled * 0.5 + 'px';
});

// Feature hover effect
document.querySelectorAll('.feature-item').forEach(item => {
    item.addEventListener('mouseenter', () => {
        item.querySelector('.feature-icon').style.transform = 'scale(1.1) rotate(5deg)';
    });
    
    item.addEventListener('mouseleave', () => {
        item.querySelector('.feature-icon').style.transform = 'scale(1) rotate(0deg)';
    });
});

// Pricing toggle functionality
const billingToggle = document.getElementById('billing-toggle');
const pricingCards = document.querySelectorAll('.pricing-card');

billingToggle.addEventListener('change', () => {
    pricingCards.forEach(card => {
        card.classList.toggle('annual-active');
    });
});

// Initialize vanilla-tilt for pricing cards
VanillaTilt.init(document.querySelectorAll(".pricing-card"), {
    max: 5,
    speed: 400,
    glare: true,
    "max-glare": 0.3,
});
